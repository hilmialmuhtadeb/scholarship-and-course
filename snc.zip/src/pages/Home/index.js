import React from 'react';

const Home = () => {
  return (
    <div className="container">
      <p className="text-danger">Haloo</p>
    </div>
  )
}

export default Home