import Home from "./Home";
import Scholarship from "./Scholarship";

export { Home, Scholarship };